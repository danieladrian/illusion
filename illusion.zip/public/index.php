<?php
session_start();

require_once __DIR__."/../core/init.php";
require_once __DIR__."/../core/core.php";
require_once __DIR__."/../app/boot.php";

?>
