<?php

define("fetch_as_object",PDO::FETCH_OBJ);
define("fetch_as_assoc",PDO::FETCH_ASSOC);
define("fetch_as_num",PDO::FETCH_NUM);
define("fetch_as_both",PDO::FETCH_BOTH);
define("fetch_as_lazy",PDO::FETCH_LAZY);

?>
