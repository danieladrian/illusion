<?php

$Loader = (new \josegonzalez\Dotenv\Loader(__DIR__.'\..\..\..\.env'))
          ->parse()
          ->define();
?>
