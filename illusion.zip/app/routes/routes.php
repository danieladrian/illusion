<?php
// add route to collection
// do auth checking in here
if(auth::guest()){

Routes::add("/","default","welcome@index");

}
?>
