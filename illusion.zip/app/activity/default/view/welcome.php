<!DOCTYPE html>
<html>
  <head>
    <title>Welcome to Illusion</title>
    <?php
      View::make("include/css")->flush();
      View::make("include/meta")->flush();
     ?>
  </head>
  <body>
    <center>
      <div class="w3-container" >
        <div class="w3-display-middle">
          <div class="w3-row " style="width:350px;">
      <div class="w3-col s3 m3 l3 w3-padding"><img src="asset/images/logo.png" width="100px" /></div>

        <div class="w3-col s9 m9 l9 w3-padding"><h2><i>Illusion</i></h2></div>
      </div>
      <div class="w3-row" style="width:800px;">
        <div class="w3-col s12 m12 l12 w3-padding"><hr /><b>A framework from scratch</b><hr />
          <a href="#">Documentation</a> | <a href="#">Forum</a> | <a href="#">News</a>
        </div>
      </div>
      </div>
    </center>
    <?php
      View::make("include/js")->flush();
     ?>
  </body>
</html>
