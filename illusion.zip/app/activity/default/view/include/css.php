<!-- App Side-->
<link href="asset/css/style.css" rel="stylesheet" type="text/css" />

<!-- Plugin Side-->
<link href="asset/plugin/w3css/w3.css" rel="stylesheet" type="text/css" />
<link href="asset/plugin/materialize/css/materialize.css" rel="stylesheet" type="text/css" />
<link href="asset/plugin/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
