<?php
use illusion\Checksum;
use illusion\Header;

class welcome extends Controller{
  public function index(){
    
    return View::make("welcome");
  }
}
?>
