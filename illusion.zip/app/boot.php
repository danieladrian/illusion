<?php
$app=new illusion();


//$app->maintainence();
//$app->auth();
$app->start();
?>
