<?php
use illusion\Session;

class auth{
     public static function guest(){
        return true;
     }
}
?>
