<?php
$func=[];

for($i=0;$i<count($func);$i++){
  include_once "$func[$i]/$func[$i].php";
}
?>
