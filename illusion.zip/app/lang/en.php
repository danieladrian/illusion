<?php

define("january","January");
define("february","February");
define("march","March");
define("april","April");
define("may","May");
define("june","June");
define("july","July");
define("august","August");
define("september","September");
define("october","October");
define("november","November");
define("december","December");
define("monday","Monday");
define("tuesday","Tuesday");
define("wednesday","Wednesday");
define("thursday","Thursday");
define("friday","Friday");
define("saturday","Saturday");
define("sunday","Sunday");

//user

?>